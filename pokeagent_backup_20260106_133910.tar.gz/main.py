# main.py
import os
import logging
import sys
import time
from config import config as CFG
from agent.emulator import EmulatorHarness
from agent.agent import MasterAgent

def init_llm():
    """
    Inizializza il cliente per il modello Qwen3-VL-2B con ottimizzazioni avanzate.
    Supporta multiple backends: Hugging Face Transformers, Ollama, vLLM.
    """
    print("[System] Inizializzazione ottimizzata modello Qwen3-VL-2B...")
    
    from agent.llm import OllamaLLMClient, LLMConfig
    llm_config = LLMConfig(
        enabled=CFG.LLM_ENABLED,
        host=CFG.LLM_HOST,
        model=CFG.LLM_MODEL,
        temperature=CFG.LLM_TEMPERATURE,
        timeout=CFG.LLM_TIMEOUT,
        min_interval_ms=CFG.LLM_MIN_INTERVAL_MS,
        max_calls_per_minute=CFG.LLM_MAX_CALLS_PER_MINUTE,
        cache_ttl_seconds=CFG.LLM_CACHE_TTL_SECONDS,
        use_vision=CFG.LLM_USE_VISION,
        use_for_exploration=CFG.LLM_USE_FOR_EXPLORATION,
        use_for_battle=CFG.LLM_USE_FOR_BATTLE,
        use_for_menu=CFG.LLM_USE_FOR_MENU,
        fallback_on_error=CFG.LLM_FALLBACK_ON_ERROR,
        retry_attempts=CFG.LLM_RETRY_ATTEMPTS,
        consecutive_failure_threshold=CFG.LLM_CONSECUTIVE_FAILURE_THRESHOLD,
        failure_cooldown_seconds=CFG.LLM_FAILURE_COOLDOWN_SECONDS
    )
    if not llm_config.enabled:
        raise RuntimeError("LLM disabilitato in Config ma richiesto per il controllo autonomo.")
    client = OllamaLLMClient(llm_config)
    probe = client.generate_text("Rispondi solo con: OK")
    if not probe or "OK" not in probe.upper():
        raise RuntimeError("Impossibile comunicare con Ollama/Qwen. Verifica che Ollama sia in esecuzione e che il modello sia disponibile.")
    return client

def main():
    """Funzione principale per avviare l'agente Pokemon con ottimizzazioni avanzate."""
    print("=== Avvio Agente Pokemon basato su Qwen3-VL (Versione Ottimizzata) ===")

    logging.basicConfig(
        level=getattr(logging, str(CFG.LOG_LEVEL).upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        handlers=[logging.FileHandler(CFG.LOG_FILE), logging.StreamHandler(sys.stdout)]
    )
    
    # Metriche di performance
    performance_stats = {
        'total_steps': 0,
        'successful_steps': 0,
        'llm_calls': 0,
        'avg_step_time': 0.0,
        'start_time': time.time()
    }

    try:
        # 1. Inizializza i componenti con gestione errori robusta
        rom_path = CFG.ROM_PATH
        emulator = EmulatorHarness(rom_path)
        llm_client = init_llm()

        # 2. Crea l'agente maestro
        master_agent = MasterAgent(emulator, llm_client)

        # 3. Ciclo principale di esecuzione ottimizzato
        max_steps = int(os.getenv("POKEAGENT_MAX_STEPS", "1000"))
        step_target_seconds = float(os.getenv("POKEAGENT_STEP_TARGET_S", "0.05"))
        
        for step in range(max_steps):
            step_start_time = time.time()
            performance_stats['total_steps'] += 1
            performance_stats['llm_calls'] = getattr(llm_client, "call_count", performance_stats['llm_calls'])
            
            print(f"\n{'='*40}")
            print(f"Step {step+1}/{max_steps} | LLM Calls: {performance_stats['llm_calls']}")
            print(f"Success Rate: {performance_stats['successful_steps']/performance_stats['total_steps']*100:.1f}%")
            print(f"{'='*40}")
            
            try:
                # Esegue lo step con timeout
                master_agent.run_step()
                performance_stats['successful_steps'] += 1
                
                # Calcolo tempo medio adattivo
                step_time = time.time() - step_start_time
                performance_stats['avg_step_time'] = (
                    performance_stats['avg_step_time'] * 0.9 + step_time * 0.1
                )
                
                # Pausa adattiva basata sul tempo di esecuzione
                adaptive_sleep = max(0.0, step_target_seconds - step_time)
                time.sleep(adaptive_sleep)
                
            except KeyboardInterrupt:
                print("\nInterruzione da tastiera. Arresto.")
                break
                
            except Exception as e:
                print(f"Errore critico nello step {step}: {e}")
                # Backoff esponenziale per errori consecutivi
                error_count = performance_stats['total_steps'] - performance_stats['successful_steps']
                sleep_time = min(10, 2 ** error_count)
                time.sleep(sleep_time)
                
                if error_count > 5:
                    print("Troppi errori consecutivi. Riavvio dell'agente...")
                    break

        # Calcolo metriche finali
        total_time = time.time() - performance_stats['start_time']
        steps_per_minute = (performance_stats['total_steps'] / total_time) * 60
        
        print(f"\n=== SESSIONE TERMINATA ===")
        print(f"Tempo totale: {total_time:.1f}s")
        print(f"Step completati: {performance_stats['successful_steps']}/{performance_stats['total_steps']}")
        print(f"Tasso di successo: {performance_stats['successful_steps']/performance_stats['total_steps']*100:.1f}%")
        print(f"Step/minuto: {steps_per_minute:.1f}")
        print(f"Tempo medio per step: {performance_stats['avg_step_time']:.2f}s")
        
    except Exception as e:
        print(f"Errore durante l'inizializzazione: {e}")
        print("Assicurati che:")
        print("1. Il emulatore sia configurato correttamente")
        print("2. La ROM sia presente in ./roms/")
        print("3. Ollama sia in esecuzione per l'integrazione LLM")
        raise

if __name__ == "__main__":
    main()
