# emulator.py
import time
from PIL import Image
import numpy as np
from typing import Tuple, Dict, Any, Optional
import json


from config import config as CFG

class EmulatorHarness:
    """Gestisce l'emulatore, fornisce percezione strutturata e strumenti di azione."""

    def __init__(self, rom_path: str):
        self.rom_path = rom_path
        self.emulator = None  # Qui andrà l'istanza dell'emulatore (es. PyBoy)
        self._init_emulator()
        self.loaded_knowledge_base = self._load_knowledge_base()

    def _init_emulator(self):
        """Inizializza l'emulatore di Game Boy (DA IMPLEMENTARE)."""
        # Esempio con PyBoy:
        # from pyboy import PyBoy
        # self.emulator = PyBoy(self.rom_path, window_type="headless")
        # self.emulator.set_emulation_speed(CFG.EMULATOR_SPEED)
        print(f"[Emulator] Inizializzazione per ROM: {self.rom_path}")
        # Implementa qui la connessione al tuo emulatore

    def _load_knowledge_base(self) -> Dict:
        """Carica la knowledge base da file JSON."""
        try:
            with open(CFG.KNOWLEDGE_BASE_FILE, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"[Emulator] Knowledge base non trovata in {CFG.KNOWLEDGE_BASE_FILE}")
            return {"type_matchups": {}, "map_connections": {}, "important_npcs": {}}

    def get_current_state(self) -> Dict[str, Any]:
        """Cattura lo stato completo del gioco: screenshot + dati dalla RAM."""
        visual = self._get_screenshot()
        state = {
            "visual": visual,
            "visual_np": np.array(visual),
            "ram": self._read_ram_data(),
            "parsed": None
        }
        state["parsed"] = self._parse_state(state["ram"], visual)
        return state

    def _get_screenshot(self) -> Image.Image:
        """Cattura uno screenshot dallo schermo dell'emulatore."""
        # DA IMPLEMENTARE con il tuo emulatore
        # Esempio per PyBoy: return self.emulator.screen.image
        print("[Emulator] Cattura screenshot.")
        return Image.new('RGB', (160, 144), color='black')  # Schermo vuoto fittizio

    def _read_ram_data(self) -> Dict[str, int]:
        """Legge dati specifici dalla memoria del gioco usando gli offset definiti."""
        ram_data = {}
        for name, offset in CFG.RAM_OFFSETS.items():
            # DA IMPLEMENTARE: Lettura della memoria dall'emulatore
            # Esempio: value = self.emulator.get_memory_value(offset)
            ram_data[name] = 0  # Valore fittizio
        return ram_data

    def _parse_state(self, ram_data: Dict, screenshot: Image.Image) -> Dict[str, Any]:
        """Analizza i dati grezzi (RAM e immagine) in uno stato di gioco strutturato."""
        # QUI POTRESTI USARE QWEN3-VL PER ANALIZZARE LO SCREENSHOT
        parsed = {
            "location": f"Mappa {ram_data.get('current_map', 0)} a ({ram_data.get('player_x', 0)}, {ram_data.get('player_y', 0)})",
            "in_battle": ram_data.get('in_battle_flag', 0) == 1,
            "menu_open": ram_data.get('menu_flag', 0) == 1,
            "text_box": self._extract_text_from_screenshot(screenshot)  # Funzione complessa
        }
        return parsed

    def _extract_text_from_screenshot(self, screenshot: Image.Image) -> str:
        """Tenta di estrarre testo dallo screenshot (può usare OCR o il modello VL)."""
        # Sarebbe ideale usare Qwen3-VL per leggere il testo dall'immagine
        return "Testo del dialogo non implementato."

    # --- STRUMENTI (TOOLS) PER L'AGENTE DI ESECUZIONE ---
    def press_button(self, button: str):
        """Premi un singolo pulsante (A, B, UP, DOWN, LEFT, RIGHT, START, SELECT)."""
        # DA IMPLEMENTARE con l'API del tuo emulatore
        print(f"[Emulator] Premi: {button}")
        time.sleep(0.1)  # Breve pausa per l'animazione

    def navigate_to(self, target_map: int, target_x: int, target_y: int) -> bool:
        """
        Strumento avanzato: naviga verso coordinate specifiche.
        Restituisce True se l'azione è iniziata con successo.
        """
        if not CFG.ENABLE_PATHFINDER:
            return False
        print(f"[Tool] Pathfinding verso Mappa {target_map}, ({target_x}, {target_y})")
        # DA IMPLEMENTARE: Algoritmo di pathfinding (BFS) sulle mappe conosciute
        return True

    def search_knowledge_base(self, query: str) -> Optional[str]:
        """Cerca nella knowledge base caricata."""
        # Ricerca semplice per tipo (es. "type_matchup:water")
        if query.startswith("type_matchup:"):
            pokemon_type = query.split(":")[1].strip()
            return self.loaded_knowledge_base.get("type_matchups", {}).get(pokemon_type, "Sconosciuto")
        return None

    def solve_boulder_puzzle(self, puzzle_id: str) -> bool:
        """Risolutore specializzato per un puzzle specifico."""
        print(f"[Tool] Risolvo puzzle: {puzzle_id}")
        # DA IMPLEMENTARE: Sequenza hardcoded di pulsanti per quel puzzle
        sequence = ["UP", "RIGHT", "DOWN", "LEFT"]  # Esempio
        for btn in sequence:
            self.press_button(btn)
        return True
