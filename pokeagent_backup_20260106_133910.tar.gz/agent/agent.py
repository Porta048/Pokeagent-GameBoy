# agent.py
import json
import logging
from typing import Dict, Any, Optional, List, Tuple
from enum import Enum

from config import config as CFG
from agent.memory import memory
from agent.emulator import EmulatorHarness

class AgentPhase(Enum):
    """Fasi del ciclo di decisione dell'agente."""
    PLANNING = 1
    EXECUTION = 2
    CRITIQUE = 3

class PlanningAgent:
    """Agente responsabile della pianificazione di alto livello."""

    def __init__(self, llm_client):
        self.llm = llm_client

    def formulate_goal(self, game_state: Dict, long_term_goal: str) -> str:
        """Formula il prossimo obiettivo chiaro e fattibile."""
        prompt = CFG.PLANNER_PROMPT_TEMPLATE.format(

            
            game_state=game_state,
            long_term_goal=long_term_goal,
            recent_history=memory.get_recent_history(10),
            relevant_facts="\n".join(memory.query_facts(long_term_goal, n_results=3))
        )
        next_goal = None
        if hasattr(self.llm, "generate_text"):
            next_goal = self.llm.generate_text(prompt)
        if not next_goal:
            next_goal = "Esplora l'area, interagisci con NPC, gestisci menu e battaglie."
        next_goal = next_goal.strip().splitlines()[0][:240]
        memory.store_fact("planned_goal", next_goal, {"phase": "planning"})
        return next_goal

class ExecutionAgent:
    """Agente responsabile dell'esecuzione delle azioni a basso livello."""

    def __init__(self, emulator: EmulatorHarness, llm_client):
        self.emulator = emulator
        self.llm = llm_client
        self.step_count = 0

    def execute_task(self, task_description: str, game_state: Dict, screen_image_np, action_history: List[str]) -> Dict[str, Any]:
        """
        Esegue un singolo compito. Decide se usare uno strumento o azioni base.
        Restituisce un rapporto sull'esito.
        """
        self.step_count = 0
        outcome = {"success": False, "steps": [], "reason": ""}

        # 1. DECIDI SE USARE UNO STRUMENTO SPECIALIZZATO
        if "vai a" in task_description.lower() and CFG.ENABLE_PATHFINDER:
            # Estrai coordinate dal task (logica semplice, da migliorare)
            outcome = self._use_navigation_tool(task_description, game_state)
        elif "puzzle" in task_description.lower():
            outcome = self._use_puzzle_solver(task_description)
        else:
            # 2. ALTRIMENTI, USA L'LLM PER DECIDERE LE AZIONI DI BASE
            outcome = self._use_llm_for_basic_actions(task_description, game_state, screen_image_np, action_history)

        memory.add_event({
            "description": f"Eseguito: {task_description}",
            "outcome": outcome
        })
        return outcome

    def _use_navigation_tool(self, task: str, state: Dict) -> Dict:
        """Utilizza lo strumento di pathfinding."""
        # Logica per estrarre destinazione dal testo del task (DA MIGLIORARE)
        print(f"[Execution] Uso il tool di navigazione per: {task}")
        # Esempio fittizio: supponiamo di voler andare al Centro Pokemon (mappa 5, x=10, y=8)
        success = self.emulator.navigate_to(5, 10, 8)
        return {"success": success, "steps": ["navigate_tool_called"], "reason": "Tool di navigazione usato."}

    def _use_puzzle_solver(self, task: str) -> Dict:
        success = self.emulator.solve_boulder_puzzle("default")
        return {"success": success, "steps": ["puzzle_solver_called"], "reason": f"Tool puzzle usato per: {task}"}

    def _use_llm_for_basic_actions(self, task: str, state: Dict, screen_image_np, action_history: List[str]) -> Dict:
        """Usa l'LLM per generare una sequenza di pulsanti per compiti generici."""
        game_mode = "exploring"
        if state.get("in_battle"):
            game_mode = "battle"
        elif state.get("menu_open"):
            game_mode = "menu"

        action_index = None
        if hasattr(self.llm, "get_action"):
            game_context = {"goal": task, **state}
            action_index = self.llm.get_action(game_mode, game_context, screen_image_np, action_history[-20:])

        action = None
        if isinstance(action_index, int) and 0 <= action_index < len(CFG.ACTIONS):
            action = CFG.ACTIONS[action_index]

        if action:
            self.emulator.press_button(action.upper())
            self.step_count += 1
            return {"success": True, "steps": [action], "reason": f"Azione LLM: {action}", "action_index": action_index}

        self.step_count += 1
        return {"success": False, "steps": [], "reason": "LLM non ha prodotto un'azione valida.", "action_index": action_index}
        self.step_count += 1

        return {
            "success": True,
            "steps": [action],
            "reason": f"Azione base eseguita: {action}"
        }

class CritiqueAgent:
    """Agente responsabile della valutazione dei risultati e del feedback."""

    def __init__(self, llm_client):
        self.llm = llm_client

    def review_outcome(self, goal: str, outcome: Dict, new_state: Dict) -> Dict:
        """Valuta se l'obiettivo è stato raggiunto e suggerisce correzioni."""
        if not CFG.CRITIQUE_ENABLED:
            return {"needs_retry": False, "feedback": "Critica disabilitata."}

        prompt = f"""
        Obiettivo: {goal}
        Risultato segnalato: {outcome}
        Nuovo stato del gioco: {new_state}
        L'obiettivo è stato completamente raggiunto? Rispondi SI o NO.
        Se NO, fornisci una breve ragione.
        """
        critique_response = None
        if hasattr(self.llm, "generate_text"):
            critique_response = self.llm.generate_text(prompt)
        if not critique_response:
            critique_response = "NO"

        critique_upper = critique_response.upper()
        needs_retry = "SI" not in critique_upper and "YES" not in critique_upper
        feedback = critique_response

        memory.add_event({
            "description": f"Critica: {feedback}",
            "type": "critique"
        })
        return {"needs_retry": needs_retry, "feedback": feedback}

class MasterAgent:
    """Agente maestro che orchestra il ciclo Planning->Execution->Critique."""

    def __init__(self, emulator: EmulatorHarness, llm_client):
        self.phase = AgentPhase.PLANNING
        self.emulator = emulator
        self.llm_client = llm_client
        self.planner = PlanningAgent(llm_client)
        self.executor = ExecutionAgent(emulator, llm_client)
        self.critic = CritiqueAgent(llm_client)
        self.long_term_goal = "Sconfiggi la Lega Pokemon e diventa Campione."  # Obiettivo finale
        self.current_goal: Optional[str] = None
        self.action_history: List[str] = []
        self.step_index = 0
        self.logger = logging.getLogger("pokeagent")

    def _infer_game_mode(self, parsed_state: Dict[str, Any]) -> str:
        if parsed_state.get("in_battle"):
            return "battle"
        if parsed_state.get("menu_open"):
            return "menu"
        return "exploring"

    def run_step(self):
        self.step_index += 1
        current = self.emulator.get_current_state()
        parsed = current.get("parsed") or {}
        memory.update_working_memory(screen_state=parsed)

        if not self.current_goal or self.step_index % 25 == 1:
            self.current_goal = self.planner.formulate_goal(parsed, self.long_term_goal)
            memory.update_working_memory(goal=self.current_goal)

        game_mode = self._infer_game_mode(parsed)
        self.phase = AgentPhase.EXECUTION
        outcome = self.executor.execute_task(self.current_goal, parsed, current.get("visual_np"), self.action_history)

        chosen_action = None
        if outcome.get("steps"):
            chosen_action = outcome["steps"][-1]
            self.action_history.append(chosen_action)
            if len(self.action_history) > 200:
                self.action_history = self.action_history[-200:]
            memory.update_working_memory(action=chosen_action)

        log_payload = {
            "step": self.step_index,
            "phase": str(self.phase),
            "mode": game_mode,
            "goal": self.current_goal,
            "action": chosen_action,
            "outcome": outcome,
            "state": parsed
        }
        self.logger.info(json.dumps(log_payload, ensure_ascii=False))

        if self.step_index % 50 == 0:
            self.phase = AgentPhase.CRITIQUE
            critique = self.critic.review_outcome(self.current_goal, outcome, parsed)
            self.logger.info(json.dumps({"step": self.step_index, "phase": str(self.phase), "critique": critique}, ensure_ascii=False))
            if not critique.get("needs_retry", False):
                self.long_term_goal = self._update_long_term_goal(parsed)
        self.phase = AgentPhase.PLANNING

    def _update_long_term_goal(self, state: Dict) -> str:
        """Aggiorna l'obiettivo a lungo termine in base ai progressi."""
        # Logica semplice: se siamo in una palestra, l'obiettivo diventa sconfiggere il capopalestra.
        if "palestra" in state.get('location', '').lower():
            return f"Sconfiggi il Capopalestra in {state['location']}."
        return self.long_term_goal
