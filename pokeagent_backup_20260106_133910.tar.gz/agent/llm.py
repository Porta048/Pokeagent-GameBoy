import time
import requests
import json
import re
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any
import base64
import numpy as np
from io import BytesIO

@dataclass
class LLMConfig:
    enabled: bool = True
    host: str = "http://localhost:11434"
    model: str = "qwen3-vl:2b"
    temperature: float = 0.3
    timeout: float = 60.0
    min_interval_ms: int = 2000
    max_calls_per_minute: int = 30
    cache_ttl_seconds: int = 20
    use_vision: bool = True
    use_for_exploration: bool = True
    use_for_battle: bool = True
    use_for_menu: bool = False
    fallback_on_error: bool = True
    retry_attempts: int = 2
    consecutive_failure_threshold: int = 5  # Number of consecutive failures before temporarily disabling
    failure_cooldown_seconds: int = 60  # Time to wait before re-enabling after too many failures

class OllamaLLMClient:
    def __init__(self, config: LLMConfig):
        self.config = config
        self.available = self.config.enabled
        self.last_call_time = 0
        self.call_count = 0
        self.reset_time = time.time()
        self.cache: Dict[str, Any] = {}
        self.consecutive_failures = 0
        self.failure_cooldown_until = 0  # Timestamp when cooldown ends

    def _check_rate_limit(self) -> bool:
        current_time = time.time()
        if (current_time - self.reset_time) > 60:
            self.reset_time = current_time
            self.call_count = 0

        if self.call_count >= self.config.max_calls_per_minute:
            return False

        if (current_time - self.last_call_time) * 1000 < self.config.min_interval_ms:
            time.sleep(self.config.min_interval_ms / 1000 - (current_time - self.last_call_time))
        return True

    def _check_availability(self) -> bool:
        """Check if LLM is available, considering failure cooldown."""
        current_time = time.time()

        # Check if we're in a failure cooldown period
        if current_time >= self.failure_cooldown_until and self.failure_cooldown_until != 0:
            # Cooldown has expired, re-enable LLM
            self.consecutive_failures = 0
            self.available = self.config.enabled
            self.failure_cooldown_until = 0
            print(f"[LLM] Cooldown expired, re-enabling LLM")

        return self.available

    def _get_system_prompt(self, game_state: str) -> str:
        if game_state == "battle":
            return "You are a highly intelligent AI assisting a Pokémon trainer in a battle. Your goal is to choose the best action to win the battle. Consider Pokémon types, moves, and current HP."
        elif game_state == "exploring":
            return "You are an AI guiding a Pokémon trainer through the world. Your goal is to explore, find new Pokémon, battle trainers, and progress through the story. Avoid getting stuck in loops."
        elif game_state == "menu":
            return "You are an AI assisting a Pokémon trainer navigate menus. Your goal is to perform requested actions within the menu system."
        return "You are a highly intelligent AI assisting a Pokémon trainer in their adventure."

    def _format_game_context(self, game_context: Dict) -> str:
        formatted_context = "Current Game State:\n"
        for key, value in game_context.items():
            formatted_context += f"- {key}: {value}\n"
        return formatted_context

    def _encode_image(self, image_array: np.ndarray) -> str:
        from PIL import Image
        pil_image = Image.fromarray(image_array)
        buffered = BytesIO()
        pil_image.save(buffered, format="PNG")
        return base64.b64encode(buffered.getvalue()).decode('utf-8')

    def generate_text(self, prompt: str, system_prompt: Optional[str] = None) -> Optional[str]:
        if not self._check_availability():
            return None
        if not self._check_rate_limit():
            print("[LLM] Rate limit exceeded, skipping text generation.")
            return None
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        payload = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "stream": False
        }
        for attempt in range(self.config.retry_attempts + 1):
            try:
                response = requests.post(f"{self.config.host}/api/chat", json=payload, timeout=self.config.timeout)
                response.raise_for_status()
                data = response.json()
                if "message" in data and "content" in data["message"]:
                    content = data["message"]["content"].strip()
                elif "response" in data:
                    content = data["response"].strip()
                else:
                    print(f"[LLM] Unexpected response format during text generation: {data}")
                    continue
                self.consecutive_failures = 0
                self.last_call_time = time.time()
                self.call_count += 1
                return content
            except (requests.exceptions.RequestException, ValueError, KeyError) as e:
                print(f"[LLM] Text generation error on attempt {attempt+1}/{self.config.retry_attempts + 1}: {e}")
                self.consecutive_failures += 1
                if self.consecutive_failures >= self.config.consecutive_failure_threshold:
                    self.available = False
                    current_time = time.time()
                    self.failure_cooldown_until = current_time + self.config.failure_cooldown_seconds
                    print(f"[LLM] Too many consecutive text errors ({self.consecutive_failures}), disabling for {self.config.failure_cooldown_seconds} seconds until {time.ctime(self.failure_cooldown_until)}")
                    break
                if attempt < self.config.retry_attempts:
                    time.sleep(2 ** attempt)
            except Exception as e:
                print(f"[LLM] Unexpected text generation error: {e}")
                self.consecutive_failures += 1
                if self.consecutive_failures >= self.config.consecutive_failure_threshold:
                    self.available = False
                    current_time = time.time()
                    self.failure_cooldown_until = current_time + self.config.failure_cooldown_seconds
                    print(f"[LLM] Too many consecutive text errors ({self.consecutive_failures}), disabling for {self.config.failure_cooldown_seconds} seconds until {time.ctime(self.failure_cooldown_until)}")
                    break
                break
        return None

    def _construct_prompt(self, game_state: str, game_context: Dict, screen_image: Optional[np.ndarray], action_history: List[str]) -> List[Dict]:
        # For Ollama vision models, we need to structure the message differently
        messages = [
            {"role": "system", "content": self._get_system_prompt(game_state)},
            {"role": "user", "content": self._format_game_context(game_context) +
             f"\nAction History (last 20): {', '.join(action_history)}" +
             "\nBased on the current state, what is the best action to take? Respond with only the action index (0-8) corresponding to the action list: [None, 'up', 'down', 'left', 'right', 'a', 'b', 'start', 'select]."}
        ]

        return messages

    def get_action(self, game_state: str, game_context: Dict, screen_image: Optional[np.ndarray], action_history: List[str]) -> Optional[int]:
        # Check if LLM is available (including failure cooldown)
        if not self._check_availability():
            return None

        if not self.config.use_for_exploration and game_state == "exploring":
            return None
        if not self.config.use_for_battle and game_state == "battle":
            return None
        if not self.config.use_for_menu and game_state == "menu":
            return None

        # Simple caching
        cache_key = json.dumps({"game_state": game_state, "game_context": game_context, "action_history": action_history})
        if cache_key in self.cache:
            cached_response, cache_time = self.cache[cache_key]
            if (time.time() - cache_time) < self.config.cache_ttl_seconds:
                # Reset failure counter on successful cache hit
                self.consecutive_failures = 0
                return cached_response

        if not self._check_rate_limit():
            print("[LLM] Rate limit exceeded, falling back to RL.")
            return None

        messages = self._construct_prompt(game_state, game_context, screen_image, action_history)

        payload = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "stream": False
        }

        # Add image to the payload if vision is enabled and image is provided
        if self.config.use_vision and screen_image is not None:
            encoded_image = self._encode_image(screen_image)
            payload["images"] = [encoded_image]  # Ollama expects images as a separate field

        for attempt in range(self.config.retry_attempts + 1):
            try:
                response = requests.post(f"{self.config.host}/api/chat", json=payload, timeout=self.config.timeout)
                response.raise_for_status()
                response_data = response.json()

                # Reset failure counter on successful API call
                self.consecutive_failures = 0

                # Handle different response formats
                if 'message' in response_data and 'content' in response_data['message']:
                    content = response_data['message']['content'].strip()
                elif 'response' in response_data:
                    content = response_data['response'].strip()
                else:
                    print(f"[LLM] Unexpected response format: {response_data}")
                    continue

                # Extract the action index from the content
                # Look for numbers in the response
                import re
                numbers = re.findall(r'\d+', content)
                if numbers:
                    action_index = int(numbers[0])
                    if 0 <= action_index <= 8:
                        self.cache[cache_key] = (action_index, time.time())
                        self.last_call_time = time.time()
                        self.call_count += 1
                        return action_index
                    else:
                        print(f"[LLM] Action index out of range: {action_index}")
                        # Don't treat as failure, just return None
                        return None
                else:
                    print(f"[LLM] No valid action index found in response: {content}")
                    # Check if the content contains action words and map them to indices
                    content_lower = content.lower()
                    if 'up' in content_lower:
                        action_index = 1
                    elif 'down' in content_lower:
                        action_index = 2
                    elif 'left' in content_lower:
                        action_index = 3
                    elif 'right' in content_lower:
                        action_index = 4
                    elif 'a' in content_lower:
                        action_index = 5
                    elif 'b' in content_lower:
                        action_index = 6
                    elif 'start' in content_lower:
                        action_index = 7
                    elif 'select' in content_lower:
                        action_index = 8
                    else:
                        # No valid action found, return None
                        return None

                    if 0 <= action_index <= 8:
                        self.cache[cache_key] = (action_index, time.time())
                        self.last_call_time = time.time()
                        self.call_count += 1
                        return action_index

                # If we got a response but couldn't extract a valid action, don't treat as failure
                return None
            except (requests.exceptions.RequestException, ValueError, KeyError) as e:
                print(f"[LLM] Error on attempt {attempt+1}/{self.config.retry_attempts + 1}: {e}")

                # Increment failure counter
                self.consecutive_failures += 1

                # Check if we've exceeded the failure threshold
                if self.consecutive_failures >= self.config.consecutive_failure_threshold:
                    self.available = False
                    current_time = time.time()
                    self.failure_cooldown_until = current_time + self.config.failure_cooldown_seconds
                    print(f"[LLM] Too many consecutive failures ({self.consecutive_failures}), disabling for {self.config.failure_cooldown_seconds} seconds until {time.ctime(self.failure_cooldown_until)}")
                    break

                if attempt < self.config.retry_attempts:
                    time.sleep(2 ** attempt) # Exponential backoff
            except Exception as e:
                print(f"[LLM] Unexpected error: {e}")

                # Increment failure counter for unexpected errors too
                self.consecutive_failures += 1

                # Check if we've exceeded the failure threshold
                if self.consecutive_failures >= self.config.consecutive_failure_threshold:
                    self.available = False
                    current_time = time.time()
                    self.failure_cooldown_until = current_time + self.config.failure_cooldown_seconds
                    print(f"[LLM] Too many consecutive failures ({self.consecutive_failures}), disabling for {self.config.failure_cooldown_seconds} seconds until {time.ctime(self.failure_cooldown_until)}")
                    break
                break

        return None
