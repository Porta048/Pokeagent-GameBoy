# memory.py
import json
from datetime import datetime
from typing import List, Dict, Any, Optional
# Import per DB vettoriale (es. Chroma). Ricorda di installare: pip install chromadb
try:
    import chromadb
    from chromadb.config import Settings
except ImportError:
    chromadb = None
    print("Avviso: chromadb non installato. La memoria a lungo termine sarà disabilitata.")

from config import config as CFG

class HybridMemory:
    """Gestisce memoria di lavoro, a breve e a lungo termine per l'agente."""

    def __init__(self):
        self.working_memory = {
            "current_goal": None,
            "last_action": None,
            "current_screen_state": None
        }
        self.short_term_memory = []  # Lista di eventi recenti
        self.long_term_memory_client = None
        self.long_term_memory_collection = None
        self._init_long_term_memory()

    def _init_long_term_memory(self):
        """Inizializza il client del database vettoriale per la memoria a lungo termine."""
        if chromadb:
            self.long_term_memory_client = chromadb.PersistentClient(
                path=CFG.LONG_TERM_MEMORY_PATH,
                settings=Settings(allow_reset=True, anonymized_telemetry=False)
            )
            # Crea/ottieni una collezione per i fatti del gioco
            self.long_term_memory_collection = self.long_term_memory_client.get_or_create_collection(
                name="pokemon_game_facts"
            )

    def update_working_memory(self, goal=None, action=None, screen_state=None):
        """Aggiorna la memoria di lavoro (stato immediato)."""
        if goal:
            self.working_memory["current_goal"] = goal
        if action:
            self.working_memory["last_action"] = action
        if screen_state:
            self.working_memory["current_screen_state"] = screen_state

    def add_event(self, event: Dict[str, Any]):
        """Aggiunge un evento alla memoria a breve termine e controlla se riassumere."""
        event["timestamp"] = datetime.now().isoformat()
        self.short_term_memory.append(event)

        # Controlla se è il momento di riassumere una parte della memoria
        if len(self.short_term_memory) % CFG.MEMORY_SUMMARIZE_EVERY_N_STEPS == 0:
            self._summarize_old_events()

    def get_recent_history(self, num_events: int = 10) -> str:
        """Restituisce una stringa formattata degli eventi recenti per i prompt."""
        recent = self.short_term_memory[-num_events:]
        return "\n".join([f"{e['timestamp']}: {e['description']}" for e in recent])

    def _summarize_old_events(self):
        """Usa l'LLM per riassumere i vecchi eventi e salvarli come fatto nella memoria a lungo termine."""
        if not chromadb or not self.long_term_memory_collection:
            return

        events_to_summarize = self.short_term_memory[:len(self.short_term_memory)//2]  # Prendi la prima metà
        if not events_to_summarize:
            return

        # Crea un prompt per il riassunto (DA IMPLEMENTARE: chiamata a Qwen3-VL)
        summary_prompt = f"Riassumi queste azioni di gioco in un fatto conciso:\n"
        for e in events_to_summarize:
            summary_prompt += f"- {e['description']}\n"
        summary_prompt += "Fatto riassunto:"

        # QUI ANDRÀ LA CHIAMATA AL TUO MODELLO QWEN3-VL PER OTTENERE IL RIASSUNTO
        # summary_text = call_qwen_vl(summary_prompt)
        summary_text = "Implementare la chiamata a Qwen3-VL per il riassunto."

        # Salva il fatto riassunto nella memoria a lungo termine
        self.store_fact("summary", summary_text)

        # Rimuovi gli eventi riassunti dalla memoria a breve termine
        self.short_term_memory = self.short_term_memory[len(self.short_term_memory)//2:]

    def store_fact(self, fact_type: str, content: str, metadata: Optional[Dict] = None):
        """Memorizza un fatto permanente nella memoria a lungo termine (DB vettoriale)."""
        if self.long_term_memory_collection:
            doc_id = f"fact_{datetime.now().timestamp()}"
            self.long_term_memory_collection.add(
                documents=[content],
                metadatas=[{"type": fact_type, **(metadata or {})}],
                ids=[doc_id]
            )

    def query_facts(self, query: str, n_results: int = 3) -> List[str]:
        """Recupera fatti rilevanti dalla memoria a lungo termine."""
        if not self.long_term_memory_collection:
            return []
        results = self.long_term_memory_collection.query(
            query_texts=[query],
            n_results=n_results
        )
        return results['documents'][0] if results['documents'] else []

# Istanza globale della memoria
memory = HybridMemory()
